<template>
	<div>
		更具体的酒店信息
	</div>
</template>

<script>
</script>

<style>
</style>