<template>
	<div>
		更具体的停车场信息
	</div>
</template>

<script>
</script>

<style>
</style>