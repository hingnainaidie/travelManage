<template>
	<div>
		工作人员上传旅游事件（和它的现场信息），接收到指挥中心对该旅游事件的指令和诱导
	</div>
</template>

<script>
</script>

<style>
</style>