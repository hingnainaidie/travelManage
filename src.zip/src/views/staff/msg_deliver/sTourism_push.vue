<template>
	<div>
		发布旅游信息
	</div>
</template>

<script>
</script>

<style>
</style>