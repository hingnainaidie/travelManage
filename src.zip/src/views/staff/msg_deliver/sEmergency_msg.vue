<template>
	<div>
		接收指挥中心发来的预警信息
	</div>
</template>

<script>
</script>

<style>
</style>