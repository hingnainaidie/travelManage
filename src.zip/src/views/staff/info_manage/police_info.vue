<template>
	<div>
		公安监控信息
	</div>
</template>

<script>
</script>

<style>
</style>