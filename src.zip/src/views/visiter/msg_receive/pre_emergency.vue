<template>
	<div>
		预警信息
	</div>
</template>

<script>
</script>

<style>
</style>